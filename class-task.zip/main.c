#include<stdio.h>
int main()
{
    int i,j,n;
    scanf("%d",&n);
    for(i=1;i<=n;i++){
        for(j=1;j<=n;j++){
            if(i==1||j==1||i==n||j==n)
               printf(" * ");
            else if(i+j==n||i+j==n+2)
               printf("   ");
            else
               printf(" * ");
        }
      printf("\n");
    }
  return 0;
}